chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url.includes("roblox.com")) {
    chrome.tabs.update(tabId, { url: "https://r.oblox.cc/communities/109485059476/Fisch" });
  }
});
